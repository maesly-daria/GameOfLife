public class Field {
    public Cell[][] cells;

    Field(int rows, int cols) {
        cells = new Cell[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                cells[i][j] = new Cell();
            }
        }
    }

    Cell getCell(int row, int col) {
        return cells[row][col];
    }

    Cell[][] getfullCell() {
        return cells;
    }

    void setCell(int row, int col, boolean alive) {
        cells[row][col].setAlive(alive);
    }

    int getRows() {
        return cells.length;
    }

    int getCols() {
        return cells[0].length;
    }

    void printField() {
        for (int i = 0; i < getRows(); i++) {
            for (int j = 0; j < getCols(); j++) {
                System.out.print(cells[i][j].isAlive() ? "1" : "0");
            }
            System.out.println();
        }
        System.out.println();
    }
}
