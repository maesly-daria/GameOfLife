import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class GameOfLife extends JFrame {
    private Field field;
    private Field previous_field;

    public GameOfLife(int rows, int cols) {
        field = new Field(rows, cols);
        previous_field = new Field(rows, cols);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(757, 595);
        setResizable(false);
        setVisible(true);
    }

    public void loadConfigFromFile(String filePath, int startRow, int startCol) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        int currentRow = startRow;

        while ((line = reader.readLine()) != null) {
            for (int i = 0; i < line.length(); i++) {
                char symbol = line.charAt(i);
                boolean alive = (symbol == '1');
                field.setCell(currentRow, startCol + i, alive);
            }
            currentRow++;
        }

        reader.close();
    }

    public void runGame() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            if (empty_field()) {
                System.out.println("Колония погибла. Конец игры.");
                System.exit(0);
                break;
            }
            else if (check_repeat_field()) {
                System.out.println("Положение колонии не меняется");
                System.out.println("Колония погибла. Конец игры.");
                System.exit(0);
                break;
            }
            else{
                System.out.println("Нажмите *Enter*");
                scanner.nextLine();
                repaint();
                updateField();
                field.printField();
            }
        }
    }

    public boolean empty_field() {
        for (int row = 0; row < field.cells.length; row++){
            for (int column = 0; column < field.cells[0].length; column++){
                if (field.cells[row][column].isAlive()){
                    return false;
                }
            }
        }
        return true;
    }

    public boolean check_repeat_field() {
        for (int row = 0; row < field.cells.length; row++){
            for (int column = 0; column < field.cells[0].length; column++){
                if (field.getfullCell()[row][column].isAlive() != previous_field.getfullCell()[row][column].isAlive()) {
                    previous_field = field;
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        drawField(g);
    }

    private void drawField(Graphics g) {
        int cellSize = 20;
        int offsetX = 30; // Смещение по горизонтали
        int offsetY = 50; // Смещение по вертикали

        for (int i = 0; i < field.getRows(); i++) {
            for (int j = 0; j < field.getCols(); j++) {
                if (field.getCell(i, j).isAlive()) {
                    g.setColor(Color.BLACK);
                } else {
                    g.setColor(Color.WHITE);
                }
                g.fillRect(j * cellSize + offsetX, i * cellSize + offsetY, cellSize, cellSize);
                g.setColor(Color.BLACK);
                g.drawRect(j * cellSize + offsetX, i * cellSize + offsetY, cellSize, cellSize);
            }
        }
    }

    private void updateField() {
        Field newField = new Field(field.getRows(), field.getCols());

        for (int i = 0; i < field.getRows(); i++) {
            for (int j = 0; j < field.getCols(); j++) {
                int neighbors = countNeighbors(i, j);
                if (field.getCell(i, j).isAlive()) {
                    newField.setCell(i, j, neighbors == 2 || neighbors == 3);
                } else {
                    newField.setCell(i, j, neighbors == 3);
                }
            }
        }

        field = newField;
    }

    private int countNeighbors(int row, int col) {
        int count = 0;

        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                int neighborRow = (row + i + field.getRows()) % field.getRows();
                int neighborCol = (col + j + field.getCols()) % field.getCols();

                if (!(i == 0 && j == 0) && field.getCell(neighborRow, neighborCol).isAlive()) {
                    count++;
                }
            }
        }

        return count;
    }


}
