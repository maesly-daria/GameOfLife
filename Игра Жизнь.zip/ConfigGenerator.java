import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class ConfigGenerator {
    public static void main(String[] args) {
    generateConfigFile("config.txt", 4, 4);
}
    public static void generateConfigFile(String filePath, int rows, int cols) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            Random random = new Random();

            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    int cellState = random.nextInt(2);  // 0 - мертвая, 1 - живая
                    writer.write(Integer.toString(cellState));
                }
                writer.newLine();
            }

            System.out.println("Файл конфигурации изменён.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}




