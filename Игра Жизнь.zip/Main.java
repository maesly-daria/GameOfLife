import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число строк: ");
        int numRows = scanner.nextInt();

        System.out.println("Введите число столбцов: ");
        int numCols = scanner.nextInt();

        System.out.println("Введите путь к файлу с исходными колониями: ");
        String filePath = scanner.next();

        System.out.println("Введите X координату колонии: ");
        int X = scanner.nextInt();

        System.out.println("Введите Y координату колонии: ");
        int Y = scanner.nextInt();

        GameOfLife game = new GameOfLife(numRows, numCols);

        try {
            game.loadConfigFromFile(filePath, Y, X);
        } catch (IOException e) {
            e.printStackTrace();
        }

        game.runGame();
    }
}
