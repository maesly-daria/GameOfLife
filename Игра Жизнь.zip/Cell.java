public class Cell {
    private boolean alive;

    Cell() {
        alive = false;
    }

    boolean isAlive() {
        return alive;
    }

    void setAlive(boolean alive) {
        this.alive = alive;
    }
}
